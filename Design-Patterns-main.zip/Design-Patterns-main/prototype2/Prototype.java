
package prototype2;

public interface Prototype {
	AccessControl clone();
}