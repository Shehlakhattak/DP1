package memento.command;

public interface Command {
    String getName();
    void execute();
}
