

package commandpattern;

public interface FileSystemReciever {
	void openFile();
	void closeFile();
	void writeFile();

}